package tinhgiaban1;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        ArrayList<Merchandise> a = new ArrayList<>();
        while(t-- >0) {
            Merchandise tmp = new Merchandise();
            tmp.input(sc);
            a.add(tmp);
        }
        for (Merchandise i : a) System.out.println(i);
    }

}
